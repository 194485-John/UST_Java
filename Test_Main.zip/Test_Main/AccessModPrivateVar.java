package com.ust.test;

class Data{
	public String name;
}
public class AccessModPrivateVar {

	public static void main(String[] args) {
		Data d=new Data();
		d.name="abc";
		

	}

}
